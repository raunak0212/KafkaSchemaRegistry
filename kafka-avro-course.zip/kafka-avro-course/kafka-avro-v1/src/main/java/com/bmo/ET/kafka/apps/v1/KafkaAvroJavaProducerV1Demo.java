package com.bmo.ET.kafka.apps.v1;

import com.example.Customer;
import com.example.SmartCoreAPIService;

import io.confluent.kafka.serializers.KafkaAvroSerializer;
import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringSerializer;

import java.util.Properties;

public class KafkaAvroJavaProducerV1Demo {

    public static void main(String[] args) {
        Properties properties = new Properties();
        // normal producer
        properties.setProperty("bootstrap.servers", "127.0.0.1:9092");
        properties.setProperty("acks", "all");
        properties.setProperty("retries", "10");
        // avro part
        properties.setProperty("key.serializer", StringSerializer.class.getName());
        properties.setProperty("value.serializer", KafkaAvroSerializer.class.getName());
        properties.setProperty("schema.registry.url", "http://127.0.0.1:8081");

        Producer<String, SmartCoreAPIService> producer = new KafkaProducer<String, SmartCoreAPIService>(properties);

        String topic = "customer-avro4";

        // copied from avro examples
        SmartCoreAPIService smartCoreAPIService = SmartCoreAPIService.newBuilder()
                .setName("abc")
                .setDeviceName("abc")
                .setDateTime("abc")
                .setTransactionId("abc")
                .setProtocol("abc")
                .setProtocolMethod("abc")
                .setUri("/ETransfer")
                .setRequestContentType("fbfb")
                .setTxnRuleType("fbfb")
                .setClientIP("fbfb")
                .setErrorHeaders("fbfb")
                .setStatusMessage("fbfb")
                //.setB64Body("")                
                .setB64Body("ewoJIkNhbmNlbFRyYW5zZmVyQmVnaW5SZXNwb25zZSI6IHsKCQkicmVzcG9uc2VIZWFkZXIiOiB7CgkJCSJyZXNwb25zZUNvZGUiOiAiMCIKCQl9LAoJCSJiZWdpblRyYW5zYWN0aW9uSWQiOiAiQ0FEV0ZBIgoJfSwKCSJDYW5jZWxUcmFuc2ZlckNvbW1pdFJlcXVlc3QiOiB7CgkJInJlcXVlc3RIZWFkZXIiOiB7CgkJCSJwYXJ0aWNpcGFudElkIjogImRoamtsbCIsCgkJCSJtZXNzYWdlVG9rZW4iOiAiZ2Zna2drIiwKCQkJImNoYW5uZWxJbmRpY2F0b3IiOiAiMSIKCQl9LAoJCSJwYXJ0aWNpcGFudFVzZXJJZCI6ICJyciIsCgkJInRyYW5zZmVyUmVmZXJlbmNlTnVtYmVyIjogImRnZ3RoIiwKCQkiYmVnaW5UcmFuc2FjdGlvbklkIjogImZnZ2dnZyIsCgkJInBhcnRpY2lwYW50UmVmZXJlbmNlTnVtYmVyIjogImdmZ2ZnZGciLAoJCSJwYXJ0aWNpcGFudFRyYW5zYWN0aW9uRGF0ZSI6ICJmZ2RnZiIKCX0sCgkiQ2FuY2VsVHJhbnNmZXJSb2xsYmFjayI6IHsKCQkicmVzcG9uc2VIZWFkZXIiOiB7CgkJCSJyZXNwb25zZUNvZGUiOiAiMCIKCQl9Cgl9Cgp9")
                .setSOAPAction("fbfb")
                .build();

        ProducerRecord<String, SmartCoreAPIService> producerRecord = new ProducerRecord<String, SmartCoreAPIService>(
                topic, smartCoreAPIService
        );

        System.out.println(smartCoreAPIService);
        producer.send(producerRecord, new Callback() {
            @Override
            public void onCompletion(RecordMetadata metadata, Exception exception) {
                if (exception == null) {
                    System.out.println(metadata);
                } else {
                    exception.printStackTrace();
                }
            }
        });

        producer.flush();
        //producer.close();

    }
}
