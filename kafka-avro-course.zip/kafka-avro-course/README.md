# Learning

This is a companion repository for my [**Confluent Schema Registry & REST Proxy course on Udemy**](https://www.udemy.com/confluent-schema-registry/?couponCode=GITHUB)

Happy learning!

<p align="center">
    <a href="https://www.udemy.com/confluent-schema-registry/?couponCode=GITHUB">
        <img src="https://i.imgur.com/kHNTGv3.jpg" alt="Confluent Schema Registry and REST Proxy Course Logo"/>
    </a>
</p>

# Content

 - Avro examples
 - Kafka Avro Producer & Consumer
 - Schema Evolutions
