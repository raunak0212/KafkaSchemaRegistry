package guru.springframework.gof.builder.director;

import java.io.IOException;

import guru.springframework.gof.builder.builders.HouseBuilder;
import guru.springframework.gof.builder.product.House;

public class ConstructionEngineer {
    private HouseBuilder houseBuilder;
    public ConstructionEngineer(HouseBuilder houseBuilder){
        this.houseBuilder = houseBuilder;
    }

    public House constructHouse() throws IOException {
        this.houseBuilder.createProducer(null);
       // this.houseBuilder.createConsumer();
       
        return this.houseBuilder.getHouse();

    }
}