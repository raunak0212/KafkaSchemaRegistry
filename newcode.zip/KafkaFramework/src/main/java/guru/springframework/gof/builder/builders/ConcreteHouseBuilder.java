package guru.springframework.gof.builder.builders;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;

import org.apache.avro.Schema;
import org.apache.avro.generic.GenericData;
import org.apache.avro.generic.GenericRecord;
import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.StringSerializer;

import guru.springframework.gof.builder.product.House;
import io.confluent.kafka.serializers.KafkaAvroSerializer;

public class ConcreteHouseBuilder implements HouseBuilder{
    private House house;

    public ConcreteHouseBuilder() {
        this.house = new House();
    }
    
    public House getHouse() {
        System.out.println("ConcreteHouseBuilder: Concrete house complete...");
        return this.house;
    }
    
	public void createProducer(String propertyFilePath) throws IOException {
		// TODO Auto-generated method stub
		  Properties clientProps=loadProperties(propertyFilePath);
		  Properties properties = new Properties();
	      properties.setProperty("bootstrap.servers", clientProps.getProperty("bootstrap.servers"));
	      properties.setProperty("key.serializer", clientProps.getProperty("key.serializer"));
	      properties.setProperty("value.serializer", clientProps.getProperty("value.serializer"));
	      properties.setProperty("schema.registry.url", clientProps.getProperty("schema.registry.url"));
	      
	      Schema avroSchema = new Schema.Parser().parse("schemapath");
	      
	       // generic record for page-view-event.
	      GenericData.Record record = new GenericData.Record(avroSchema);
	      // put the elements according to the avro schema.
	      
	      
	      // send avro message to the topic page-view-event.

	      
	      Producer<String, GenericRecord> producer = new KafkaProducer<String, GenericRecord>(clientProps);	
	      
	      ProducerRecord<String, GenericRecord> producerRecord=  new ProducerRecord<String, GenericRecord>("topic", "", record);
	      producer.send(producerRecord, new Callback() {
	            public void onCompletion(RecordMetadata metadata, Exception exception) {
	                if (exception == null) {
	                    System.out.println(metadata);
	                } else {
	                    exception.printStackTrace();
	                }
	            }
	        });
         
	      producer.flush();
	      
	}
	
	public void createConsumer(String propertyFilePath) {
		// TODO Auto-generated method stub
		
	}
	
	
	public Properties loadProperties(String  filePath) throws IOException {
		InputStream input  = new FileInputStream(filePath);
		Properties properties = new Properties();
		properties.load(input);
		
		return properties;
		
		
	}
	


}