package guru.springframework.gof.builder.product;

public class House {
	 
	 
	  private  String bootstrapServers;
	  private  String topic;
	  private  String keySerializer;
	  private  String valueSerializer;
	  private  String schemaRegistryUrl;
	  private  String schema;

	  public String setBootstrapServers(String bootstrapServers) {
			return this.bootstrapServers = bootstrapServers;
		}



		public void setTopic(String topic) {
			this.topic = topic;
		}



		public void setKeySerializer(String keySerializer) {
			this.keySerializer = keySerializer;
		}



		public void setValueSerializer(String valueSerializer) {
			this.valueSerializer = valueSerializer;
		}



		public void setSchemaRegistryUrl(String schemaRegistryUrl) {
			this.schemaRegistryUrl = schemaRegistryUrl;
		}



		public void setSchema(String schema) {
			this.schema = schema;
		}



	  
    @Override
	public String toString() {
		return "House [bootstrapServers=" + bootstrapServers + ", topic=" + topic + ", keySerializer=" + keySerializer
				+ ", valueSerializer=" + valueSerializer + ", schemaRegistryUrl=" + schemaRegistryUrl + ", schema="
				+ schema + "]";
	}

}